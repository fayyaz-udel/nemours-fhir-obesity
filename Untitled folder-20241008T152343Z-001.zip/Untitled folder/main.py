from dl_train_sig_obs import DL_models

for i in [0]:
    DL_models('obsNew',True,490,33,23,i)

