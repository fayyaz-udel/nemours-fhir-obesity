import pandas as pd

df = pd.read_csv('data/obct_0_5.csv')
df = df[df['fact_id'] == 40762638]
df.to_csv('data/obct_0_5_red.csv', index=False)